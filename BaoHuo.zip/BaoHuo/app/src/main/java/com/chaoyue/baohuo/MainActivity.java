package com.chaoyue.baohuo;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;

import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    boolean isZhiChi;
    private Button buttonBattary;
    private Button buttonBackstage;
    private Button buttonTiaozhuan;



    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        buttonBattary = findViewById(R.id.button_battary);
        buttonBackstage = findViewById(R.id.button_backstage);
        buttonTiaozhuan = findViewById(R.id.button_tiaozhuan);
        buttonBattary.setOnClickListener(this);
        buttonBackstage.setOnClickListener(this);
        buttonTiaozhuan.setOnClickListener(this);


    }



    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.button_battary:
                isZhiChi = isIgnoringBatteryOptimizations();
                if (!isZhiChi) {
                    requestIgnoreBatteryOptimizations();
                }
                break;
            case R.id.button_backstage:
                if (isXiaomi()) {
                    goXiaomiSetting();
                }
                break;
            case R.id.button_tiaozhuan:
                Intent intent=new Intent(MainActivity.this,PowerPermissionSet.class);
                startActivity(intent);
                break;


        }
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private boolean isIgnoringBatteryOptimizations() {
        boolean isIgnoring = false;
        PowerManager powerManager = (PowerManager) getSystemService(Context.POWER_SERVICE);
        if (powerManager != null) {
            isIgnoring = powerManager.isIgnoringBatteryOptimizations(getPackageName());
        }
        return isIgnoring;
    }


    @RequiresApi(api = Build.VERSION_CODES.M)
    public void requestIgnoreBatteryOptimizations() {
        try {
            Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
            intent.setData(Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }






    public static boolean isXiaomi() {
        return Build.BRAND != null && Build.BRAND.toLowerCase().equals("xiaomi");
    }
    private void goXiaomiSetting() {
        showActivity("com.miui.powerkeeper", "com.miui.powerkeeper.ui.HiddenAppsConfigActivity");
    }
    /**
     * 跳转到指定应用的指定页面
     */
    private void showActivity(@NonNull String packageName, @NonNull String activityDir) {
        Intent intent = new Intent(packageName);
        ComponentName componentName = new ComponentName("com.miui.powerkeeper", activityDir);
        intent.setComponent(componentName);
        intent.putExtra("package_name", getPackageName());
        intent.putExtra("package_label", getResources().getString(R.string.app_name));
        //检测是否有能接受该Intent的Activity存在
        List<ResolveInfo> resolveInfos = getPackageManager().queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY);
        if (resolveInfos.size() > 0) {
            startActivity(intent);
        }

    }


}
